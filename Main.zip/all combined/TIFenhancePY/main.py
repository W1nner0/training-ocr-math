from PIL import Image, ImageEnhance, ImageOps
import os


def preprocess_images(image_dir, output_dir):
    # Ensure output directory exists
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    # Process each image in the directory
    for filename in os.listdir(image_dir):
        if filename.lower().endswith('.tif'):  # Process only .tif images
            file_path = os.path.join(image_dir, filename)
            # Open the image
            with Image.open(file_path) as img:
                # Convert to grayscale
                grayscale = img.convert('L')

                # Enhance brightness and contrast
                enhancer = ImageEnhance.Brightness(grayscale)
                brighter = enhancer.enhance(1.2)  # Increase brightness by 20%

                enhancer = ImageEnhance.Contrast(brighter)
                more_contrast = enhancer.enhance(1.3)  # Increase contrast by 30%

                # Save the processed image to output directory
                output_path = os.path.join(output_dir, filename)
                more_contrast.save(output_path)


# Define your input and output directories
image_directory = r'C:\Users\As\mainorc\filestif'
output_directory = r'C:\Users\As\mainorc\enhancetif'

# Call the preprocessing function
preprocess_images(image_directory, output_directory)
