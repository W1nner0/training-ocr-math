import subprocess
import os

def generate_tr_files(image_dir, output_dir):
    # Ensure tesseract is available in the PATH or provide the full path to the tesseract executable
    tesseract_cmd = 'tesseract'

    # Loop through all TIFF files in the directory
    for filename in os.listdir(image_dir):
        if filename.endswith('.tif'):
            # Remove the file extension to use as a base name
            basename = filename[:-4]
            image_path = os.path.join(image_dir, filename)
            output_path_base = os.path.join(output_dir, basename)

            # Generate the .box file first (if not already generated)
            box_command = [
                tesseract_cmd,
                image_path,
                output_path_base,
                'makebox'
            ]
            subprocess.run(box_command, check=True)

            # Generate .tr files using the box file
            tr_command = [
                tesseract_cmd,
                image_path,
                output_path_base,
                'nobatch',
                'box.train'
            ]
            subprocess.run(tr_command, check=True)

# Specify the directory containing your images
image_directory = r'C:\Users\As\MainORC\enhancetif'
# Specify the directory where you want to save the output files
output_directory = r'C:\Users\As\MainORC\enhancetif\tr'
generate_tr_files(image_directory, output_directory)
