import os
from PIL import Image

def convert_png_to_tiff(source_directory, output_directory):
    """
    Converts all PNG images in the source_directory to TIFF format and
    saves them in the output_directory. Prints the names of converted files.

    :param source_directory: Directory containing PNG images.
    :param output_directory: Directory where TIFF images will be saved.
    """
    # Create the output directory if it does not exist
    if not os.path.exists(output_directory):
        os.makedirs(output_directory)

    # Iterate over all files in the source directory
    for filename in os.listdir(source_directory):
        # Check if the file is a PNG image
        if filename.lower().endswith('.png'):
            # Create the full file path
            png_path = os.path.join(source_directory, filename)
            # Load the image
            image = Image.open(png_path)
            # Convert the image to TIFF
            tiff_path = os.path.join(output_directory, os.path.splitext(filename)[0] + '.tif')
            # Save the image in TIFF format
            image.save(tiff_path, format='TIFF')
            # Print the conversion information
            print(f"Converted: {png_path} to {tiff_path}")


convert_png_to_tiff(r'C:\Users\As\Downloads\IMG\IMG', r'C:\Users\As\Downloads\IMG\tif')
