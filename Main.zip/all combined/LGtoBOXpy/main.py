import os


def parse_lg_content(content):
    lines = content.split('\n')
    id_to_char = {}
    box_file_lines = []

    for line in lines:
        if line.startswith('O,'):
            parts = line.split(',')
            char_id = parts[1].strip()
            character = parts[2].strip()
            character = character.replace('ast', '*').replace('hyphen', '-')
            id_to_char[char_id] = character

    for line in lines:
        if line.startswith('#sym,'):
            parts = line.split(',')
            if len(parts) >= 6:
                sym_id = parts[1].strip()
                left, bottom, right, top = map(str.strip, parts[2:6])
                character = id_to_char.get(sym_id, '')
                box_line = f"{character} {left} {bottom} {right} {top} 0"
                box_file_lines.append(box_line)

    return '\n'.join(box_file_lines)


def convert_lg_to_box(input_directory, output_directory):
    if not os.path.exists(output_directory):
        os.makedirs(output_directory)

    for filename in os.listdir(input_directory):
        if filename.endswith('.lg'):
            lg_path = os.path.join(input_directory, filename)
            with open(lg_path, 'r') as file:
                content = file.read()

            box_content = parse_lg_content(content)
            box_filename = f"{os.path.splitext(filename)[0]}.box"
            box_path = os.path.join(output_directory, box_filename)

            with open(box_path, 'w') as file:
                file.write(box_content)

            print(f"Processed {filename} -> {box_filename}")


# Usage
# Provide the directory where your .lg files are located
input_directory_path = r'C:\Users\As\Downloads\LG\LG'
# Provide the directory where you want to save the .box files
output_directory_path = r'C:\Users\As\Downloads\LG\box'
convert_lg_to_box(input_directory_path, output_directory_path)
