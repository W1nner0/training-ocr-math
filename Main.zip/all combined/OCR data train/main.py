import pytesseract
from PIL import Image
import subprocess

subprocess.run(['tesseract', 'input.tif', 'outputbase', 'nobatch', 'box.train'])
subprocess.run(['unicharset_extractor', '*.box'])
subprocess.run(['mftraining', '-F', 'font_properties', '-U', 'unicharset', '-O', 'lang.unicharset', '*.tr'])
subprocess.run(['cntraining', '*.tr'])
subprocess.run(['mv', 'shapetable', 'lang.shapetable'])
subprocess.run(['mv', 'normproto', 'lang.normproto'])
subprocess.run(['mv', 'inttemp', 'lang.inttemp'])
subprocess.run(['mv', 'pffmtable', 'lang.pffmtable'])
subprocess.run(['combine_tessdata', 'lang.'])

# Open image
image = Image.open('image.png')

# Perform OCR
text = pytesseract.image_to_string(image, lang='eng+equ')  # Specify language model for English and equations
