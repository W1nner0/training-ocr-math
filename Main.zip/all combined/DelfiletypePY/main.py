import glob
import os

# Specify the directory to search for files
directory = r'C:\Users\As\tif'

# Define the file type to delete (e.g., '.txt' for text files)
file_type = '*.tr'

# Create a full search pattern
search_pattern = os.path.join(directory, file_type)

# Find all files of the specified type
files_to_delete = glob.glob(search_pattern)

# Iterate over the list of file paths and delete each file
for file_path in files_to_delete:
    try:
        os.remove(file_path)
        print(f"Deleted: {file_path}")
    except Exception as e:
        print(f"Error deleting {file_path}: {e}")
